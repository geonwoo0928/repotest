package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.Link;
import org.apache.catalina.startup.Tomcat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class linkTestController {
//    Link link1 = new Link(7,0,"Tom",180,80);
//    Link link2 = new Link(3,0,null,0,0);
//    Link link3 = new Link(11,0,null,0,0);
//    Link link4 = new Link(15,3,null,0,0);
//    List<Link> list = new ArrayList<>(Arrays.asList(link1, link2, link3, link4));
    @GetMapping("/main")
    public String main(Model model){
        model.addAttribute("id", 7);
        model.addAttribute("name", "Tom");
        model.addAttribute("height", 180);
        model.addAttribute("weight",80);
        return "articles/main";
    }
    @GetMapping("/articles/list")
    public String listAll(){
        return "/articles/list_all";
    }
    @GetMapping("/articles/{id}")
    public String listOne(@PathVariable("id") int id, Model model){
        model.addAttribute("id",id);
        return "/articles/list_one";
    }
    @GetMapping("/articles/create")
    public String new2 (@RequestParam("name") String name, @RequestParam("weight") int weight , @RequestParam("height") int height, Model model){
        model.addAttribute("name",  name);
        model.addAttribute("weight", weight);
        model.addAttribute("height", height);
        return "/articles/new";
    }
    @GetMapping("articles/update")
    public String updateOK (){
        return "/articles/update_ok";
    }
    @GetMapping("articles/{id}/update")
    public String update(@PathVariable("id") int id , Model model){
        model.addAttribute("id", id);
        return "/articles/update";
    }
    @GetMapping("articles/{id}/delete")
    public String delete(@PathVariable("id") int id, Model model){
        model.addAttribute("id" , id);
        return "articles/delete_ok";
    }
    @GetMapping("articles/{id}/articleComment")
    public String comment(@PathVariable("id") int id, Model model){
        model.addAttribute("id", id);
        return "articles/comment_view";
    }
    @GetMapping("/articles/{id}/articleComments/{article-comment-id}/delete")
    public String deleteComment(@PathVariable("id") int id, @PathVariable("article-comment-id") int commentId, Model model){
        model.addAttribute("id", id);
        model.addAttribute("article-comment-id", commentId);
        return "articles/delete_comment_ok";
    }


}
